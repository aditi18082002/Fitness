
## Instructions

Watch the video:

 [![Alt text](https://img.youtube.com/vi/KMkmA4i2FQc/hqdefault.jpg)](https://youtu.be/KMkmA4i2FQc)

## Custom functions

Clone this repo. Further instructions are in the video.  [harperdb-cloudfunction-example](https://github.com/python-engineer/harperdb-cloudfunction-example)
